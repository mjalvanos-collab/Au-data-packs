# AU Data Packs — Autopilot (GitHub Pages + Payhip Edition)
- GitHub Pages deploy
- Optional Stripe/Gumroad/Payhip
- Runs every 12 hours
